Project has updated versions on headers and footer. 
<a href="https://ibb.co/h7GZTnh"><img src="https://i.ibb.co/ngXnKVZ/garages-lifted-good.jpg" alt="garages-lifted-good" border="0"></a>




<a href="https://ibb.co/2jt7vVV"><img src="https://i.ibb.co/D7CD9cc/Car-Up.jpg" alt="Car-Up" border="0"></a>



<a href="https://ibb.co/GJ8tMM4"><img src="https://i.ibb.co/rtzcppR/Car-down.jpg" alt="Car-down" border="0"></a>
